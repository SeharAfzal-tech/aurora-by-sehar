// Velora by Sehar — product catalogue data.
// Prices are in Pakistani Rupees (PKR) and are sample values, easy to edit.

export type CategoryName =
  | 'Jewellery'
  | 'Bags & Wallets'
  | 'Makeup & Cosmetics'
  | 'Watches'
  | 'Sunglasses'
  | 'Hair Accessories'
  | 'Perfumes & Fragrances'
  | 'Beauty & Nail Accessories'
  | 'Fashion Accessories'
  | 'Gifts & Gift Sets';

export type Subcategory =
  | 'Earrings' | 'Necklaces' | 'Pendants' | 'Rings' | 'Bracelets' | 'Anklets' | 'Jewellery Sets' | 'Pearl Jewellery'
  | 'Handbags' | 'Shoulder Bags' | 'Mini Bags' | 'Clutches' | 'Wallets' | 'Crossbody Bags'
  | 'Lipsticks' | 'Lip Gloss' | 'Blush' | 'Mascara' | 'Makeup Brushes' | 'Makeup Palettes' | 'Beauty Tools'
  | 'Elegant Watches' | 'Minimal Watches' | 'Everyday Watches' | 'Fashion Watches'
  | 'Cat-Eye Sunglasses' | 'Oval Sunglasses' | 'Square Sunglasses' | 'Classic Sunglasses'
  | 'Claw Clips' | 'Scrunchies' | 'Hairbands' | 'Hair Bows' | 'Decorative Hair Pins'
  | "Women's Perfumes" | 'Body Mists' | 'Fragrance Gift Sets'
  | 'Press-On Nails' | 'Nail Art Accessories' | 'Cosmetic Pouches' | 'Makeup Organizers'
  | 'Scarves' | 'Belts' | 'Brooches' | 'Fashion Accessories'
  | 'Jewellery Gift Boxes' | 'Birthday Gifts' | 'Gift Sets' | 'Special Occasion Gifts';

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  salePrice?: number;
  category: CategoryName;
  subcategory: Subcategory;
  image: string;
  images?: string[];
  badge?: 'New Arrival' | 'Featured' | 'Best Seller' | 'Sale';
  collection?: string;
  isNew?: boolean;
  isBestSeller?: boolean;
}

// --- Image URLs (Pexels) ---
const img = {
  earrings1: 'https://images.pexels.com/photos/29038003/pexels-photo-29038003.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  earrings2: 'https://images.pexels.com/photos/34399039/pexels-photo-34399039.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  earrings3: 'https://images.pexels.com/photos/7615245/pexels-photo-7615245.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  earrings4: 'https://images.pexels.com/photos/9634288/pexels-photo-9634288.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  goldFlatlay: 'https://images.pexels.com/photos/32610505/pexels-photo-32610505.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  goldFlatlay2: 'https://images.pexels.com/photos/7248760/pexels-photo-7248760.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  goldFlatlay3: 'https://images.pexels.com/photos/9478016/pexels-photo-9478016.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  pearl1: 'https://images.pexels.com/photos/10556215/pexels-photo-10556215.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  pearl2: 'https://images.pexels.com/photos/8776984/pexels-photo-8776984.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  pearl3: 'https://images.pexels.com/photos/36499014/pexels-photo-36499014.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  bag1: 'https://images.pexels.com/photos/7953286/pexels-photo-7953286.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  bag2: 'https://images.pexels.com/photos/12643950/pexels-photo-12643950.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  bag3: 'https://images.pexels.com/photos/11980639/pexels-photo-11980639.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  makeup1: 'https://images.pexels.com/photos/17156387/pexels-photo-17156387.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  makeup2: 'https://images.pexels.com/photos/7290627/pexels-photo-7290627.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  makeup3: 'https://images.pexels.com/photos/7256145/pexels-photo-7256145.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  makeupPal1: 'https://images.pexels.com/photos/32388555/pexels-photo-32388555.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  makeupPal2: 'https://images.pexels.com/photos/4774061/pexels-photo-4774061.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  makeupPal3: 'https://images.pexels.com/photos/7675421/pexels-photo-7675421.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  watch1: 'https://images.pexels.com/photos/15631259/pexels-photo-15631259.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  watch2: 'https://images.pexels.com/photos/8160609/pexels-photo-8160609.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  watch3: 'https://images.pexels.com/photos/10557834/pexels-photo-10557834.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  sunglasses1: 'https://images.pexels.com/photos/15674425/pexels-photo-15674425.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  sunglasses2: 'https://images.pexels.com/photos/7060330/pexels-photo-7060330.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  sunglasses3: 'https://images.pexels.com/photos/27902336/pexels-photo-27902336.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  hair1: 'https://images.pexels.com/photos/20166053/pexels-photo-20166053.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  perfume1: 'https://images.pexels.com/photos/21008941/pexels-photo-21008941.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  perfume2: 'https://images.pexels.com/photos/20591858/pexels-photo-20591858.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  perfume3: 'https://images.pexels.com/photos/15097440/pexels-photo-15097440.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  nailPouch1: 'https://images.pexels.com/photos/39430366/pexels-photo-39430366.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  nailPouch2: 'https://images.pexels.com/photos/29821662/pexels-photo-29821662.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  nailPouch3: 'https://images.pexels.com/photos/34835280/pexels-photo-34835280.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  scarf1: 'https://images.pexels.com/photos/33171972/pexels-photo-33171972.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  scarf2: 'https://images.pexels.com/photos/39287567/pexels-photo-39287567.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  scarf3: 'https://images.pexels.com/photos/34875769/pexels-photo-34875769.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  gift1: 'https://images.pexels.com/photos/33629669/pexels-photo-33629669.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  gift2: 'https://images.pexels.com/photos/33629666/pexels-photo-33629666.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  gift3: 'https://images.pexels.com/photos/33629668/pexels-photo-33629668.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ring1: 'https://images.pexels.com/photos/2732096/pexels-photo-2732096.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ring2: 'https://images.pexels.com/photos/2849742/pexels-photo-2849742.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  ring3: 'https://images.pexels.com/photos/30541171/pexels-photo-30541171.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  bracelet1: 'https://images.pexels.com/photos/35598284/pexels-photo-35598284.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  bracelet2: 'https://images.pexels.com/photos/14509641/pexels-photo-14509641.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  bracelet3: 'https://images.pexels.com/photos/32392679/pexels-photo-32392679.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  jewelleryBox: 'https://images.pexels.com/photos/10582459/pexels-photo-10582459.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  jewelleryBox2: 'https://images.pexels.com/photos/8345752/pexels-photo-8345752.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  pearlEditorial: 'https://images.pexels.com/photos/6641219/pexels-photo-6641219.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  womanEditorial: 'https://images.pexels.com/photos/29888727/pexels-photo-29888727.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
};

export const heroImage = img.pearlEditorial;
export const heroImageSecondary = img.womanEditorial;

export const categories: { name: CategoryName; subcategories: Subcategory[]; image: string; description: string }[] = [
  { name: 'Jewellery', subcategories: ['Earrings','Necklaces','Pendants','Rings','Bracelets','Anklets','Jewellery Sets','Pearl Jewellery'], image: img.goldFlatlay, description: 'Pieces that finish every look.' },
  { name: 'Bags & Wallets', subcategories: ['Handbags','Shoulder Bags','Mini Bags','Clutches','Wallets','Crossbody Bags'], image: img.bag1, description: 'Carry it with confidence.' },
  { name: 'Makeup & Cosmetics', subcategories: ['Lipsticks','Lip Gloss','Blush','Mascara','Makeup Brushes','Makeup Palettes','Beauty Tools'], image: img.makeup1, description: 'Beauty, beautifully made.' },
  { name: 'Watches', subcategories: ['Elegant Watches','Minimal Watches','Everyday Watches','Fashion Watches'], image: img.watch1, description: 'Time, made timeless.' },
  { name: 'Sunglasses', subcategories: ['Cat-Eye Sunglasses','Oval Sunglasses','Square Sunglasses','Classic Sunglasses'], image: img.sunglasses2, description: 'See the world in style.' },
  { name: 'Hair Accessories', subcategories: ['Claw Clips','Scrunchies','Hairbands','Hair Bows','Decorative Hair Pins'], image: img.hair1, description: 'The perfect finishing touch.' },
  { name: 'Perfumes & Fragrances', subcategories: ["Women's Perfumes",'Body Mists','Fragrance Gift Sets'], image: img.perfume1, description: 'Your signature scent.' },
  { name: 'Beauty & Nail Accessories', subcategories: ['Press-On Nails','Nail Art Accessories','Cosmetic Pouches','Makeup Organizers'], image: img.nailPouch1, description: 'Details that delight.' },
  { name: 'Fashion Accessories', subcategories: ['Scarves','Belts','Brooches','Fashion Accessories'], image: img.scarf3, description: 'The art of accessorising.' },
  { name: 'Gifts & Gift Sets', subcategories: ['Jewellery Gift Boxes','Birthday Gifts','Gift Sets','Special Occasion Gifts'], image: img.gift3, description: 'For the ones you love.' },
];

export const collections: { id: string; title: string; subtitle: string; description: string; image: string; filter: (p: Product) => boolean }[] = [
  { id: 'golden-edit', title: 'The Golden Edit', subtitle: 'Gold-tone jewellery', description: 'Elegant gold-tone jewellery, necklaces, rings, and earrings — our most radiant pieces in one place.', image: img.goldFlatlay2, filter: (p) => p.category === 'Jewellery' && (p.subcategory.includes('Earrings') || p.subcategory.includes('Necklaces') || p.subcategory.includes('Rings') || p.subcategory.includes('Pendants') || p.subcategory.includes('Bracelets')) && !p.subcategory.includes('Pearl') },
  { id: 'pearls-grace', title: 'Pearls & Grace', subtitle: 'Timeless pearls', description: 'Pearl earrings, necklaces, bracelets, and timeless accessories that never go out of style.', image: img.pearl1, filter: (p) => p.subcategory === 'Pearl Jewellery' || (p.category === 'Jewellery' && p.name.toLowerCase().includes('pearl')) },
  { id: 'everyday-elegance', title: 'Everyday Elegance', subtitle: 'Minimal & wearable', description: 'Minimal jewellery and accessories for everyday use — understated, versatile, and quietly beautiful.', image: img.goldFlatlay3, filter: (p) => p.collection === 'everyday-elegance' },
  { id: 'handbag-collection', title: 'The Handbag Collection', subtitle: 'Bags for every day', description: 'Stylish handbags, mini bags, shoulder bags, and clutches — crafted to carry beautifully.', image: img.bag1, filter: (p) => p.category === 'Bags & Wallets' },
  { id: 'beauty-essentials', title: 'Beauty Essentials', subtitle: 'Makeup & tools', description: 'Makeup, cosmetic accessories, and beauty tools curated for the everyday glow.', image: img.makeup2, filter: (p) => p.category === 'Makeup & Cosmetics' || p.category === 'Beauty & Nail Accessories' },
  { id: 'finishing-touch', title: 'The Finishing Touch', subtitle: 'Watches, sunglasses & hair', description: 'Watches, sunglasses, hair accessories, and other finishing details that complete the look.', image: img.watch1, filter: (p) => p.category === 'Watches' || p.category === 'Sunglasses' || p.category === 'Hair Accessories' },
  { id: 'gifts-elegance', title: 'Gifts of Elegance', subtitle: 'Beautifully presented', description: 'Beautifully presented gifts and jewellery gift sets for every special occasion.', image: img.gift1, filter: (p) => p.category === 'Gifts & Gift Sets' || p.subcategory === 'Fragrance Gift Sets' || p.subcategory === 'Jewellery Gift Boxes' },
  { id: 'new-noteworthy', title: 'New & Noteworthy', subtitle: 'The latest arrivals', description: 'The latest products and new arrivals — fresh pieces just added to the boutique.', image: img.earrings3, filter: (p) => p.isNew === true },
  { id: 'under-1000', title: 'Under Rs. 1,000', subtitle: 'Beautiful on a budget', description: 'Affordable accessories and selected pieces within this budget — elegance doesn\'t need to be expensive.', image: img.hair1, filter: (p) => p.price < 1000 },
  { id: 'best-sellers', title: 'Best Sellers', subtitle: 'Loved by many', description: 'Our most popular products — the pieces our customers come back for again and again.', image: img.goldFlatlay, filter: (p) => p.isBestSeller === true },
];

// --- Products ---
export const products: Product[] = [
  // Jewellery — Earrings
  { id: 'earrings-gold-hoop', name: 'Gold-Tone Hoop Earrings', description: 'Classic gold-tone hoops that pair effortlessly with every outfit — from day to night.', price: 450, salePrice: 380, category: 'Jewellery', subcategory: 'Earrings', image: img.earrings1, badge: 'Sale', isBestSeller: true },
  { id: 'earrings-teardrop', name: 'Teardrop Statement Earrings', description: 'Elegant teardrop earrings with a warm gold finish — the perfect evening accent.', price: 650, category: 'Jewellery', subcategory: 'Earrings', image: img.earrings2, badge: 'Featured', isNew: true },
  { id: 'earrings-floral', name: 'Floral Stud Earrings', description: 'Delicate floral studs in gold tone — understated beauty for everyday wear.', price: 350, category: 'Jewellery', subcategory: 'Earrings', image: img.earrings3, collection: 'everyday-elegance' },
  { id: 'earrings-pearl-drop', name: 'Pearl Drop Earrings', description: 'Soft freshwater-style pearls on a gold-tone drop — quiet, timeless elegance.', price: 550, category: 'Jewellery', subcategory: 'Pearl Jewellery', image: img.pearl2, isBestSeller: true },
  { id: 'earrings-gold-set', name: 'Heart Pendant Earring Set', description: 'A romantic heart earring and pendant set, presented in a keepsake box.', price: 850, category: 'Jewellery', subcategory: 'Earrings', image: img.earrings4, badge: 'Featured' },

  // Jewellery — Necklaces
  { id: 'necklace-gold-pendant', name: 'Gold-Tone Pendant Necklace', description: 'A simple, elegant pendant on a fine gold-tone chain — a daily favourite.', price: 750, category: 'Jewellery', subcategory: 'Necklaces', image: img.goldFlatlay2, isNew: true, collection: 'everyday-elegance' },
  { id: 'necklace-pearl-strand', name: 'Pearl Strand Necklace', description: 'A classic pearl strand that elevates any neckline with effortless grace.', price: 1200, category: 'Jewellery', subcategory: 'Pearl Jewellery', image: img.pearl1, badge: 'Best Seller', isBestSeller: true },
  { id: 'necklace-gold-layered', name: 'Layered Gold Necklace', description: 'Pre-layered gold-tone chains for an effortless, curated look.', price: 950, category: 'Jewellery', subcategory: 'Necklaces', image: img.goldFlatlay, badge: 'Featured' },
  { id: 'necklace-statement', name: 'Statement Gold Necklace', description: 'A bold, gold-tone statement piece for when you want to be remembered.', price: 1400, category: 'Jewellery', subcategory: 'Necklaces', image: img.earrings1 },

  // Jewellery — Pendants
  { id: 'pendant-heart', name: 'Heart Locket Pendant', description: 'A delicate heart locket on a fine chain — keep someone close to your heart.', price: 690, category: 'Jewellery', subcategory: 'Pendants', image: img.earrings4, collection: 'everyday-elegance' },
  { id: 'pendant-pearl', name: 'Pearl Pendant', description: 'A single luminous pearl on a gold-tone pendant — quietly elegant.', price: 590, category: 'Jewellery', subcategory: 'Pearl Jewellery', image: img.pearl3 },

  // Jewellery — Rings
  { id: 'ring-gold-twist', name: 'Gold-Tone Twist Ring', description: 'A modern twisted band in gold tone — stack it or wear it solo.', price: 420, category: 'Jewellery', subcategory: 'Rings', image: img.ring1, isNew: true, collection: 'everyday-elegance' },
  { id: 'ring-stone', name: 'Stone-Set Ring', description: 'A sparkling stone-set ring with a refined gold band.', price: 780, category: 'Jewellery', subcategory: 'Rings', image: img.ring2, badge: 'Featured' },
  { id: 'ring-minimal-band', name: 'Minimal Gold Band', description: 'A clean, everyday gold-tone band — the simplest things last longest.', price: 350, category: 'Jewellery', subcategory: 'Rings', image: img.ring3, collection: 'everyday-elegance' },
  { id: 'ring-diamond', name: 'Diamond-Style Ring', description: 'A brilliant-cut stone ring that catches every light in the room.', price: 1100, category: 'Jewellery', subcategory: 'Rings', image: img.ring2, badge: 'Best Seller', isBestSeller: true },

  // Jewellery — Bracelets
  { id: 'bracelet-gold-chain', name: 'Gold-Tone Chain Bracelet', description: 'A fine gold-tone chain bracelet — a whisper of elegance on the wrist.', price: 650, category: 'Jewellery', subcategory: 'Bracelets', image: img.bracelet1, badge: 'Featured', isBestSeller: true },
  { id: 'bracelet-pearl', name: 'Pearl Bracelet', description: 'Dainty pearls strung on a gold-tone clasp — soft, timeless, beautiful.', price: 590, category: 'Jewellery', subcategory: 'Pearl Jewellery', image: img.pearl3 },
  { id: 'bracelet-bangle', name: 'Gold-Tone Bangle', description: 'A sleek bangle you can wear alone or stack with favourites.', price: 720, category: 'Jewellery', subcategory: 'Bracelets', image: img.bracelet2 },
  { id: 'bracelet-charm', name: 'Charm Bracelet', description: 'A delicate chain with tiny gold charms — tell your own story.', price: 680, category: 'Jewellery', subcategory: 'Bracelets', image: img.bracelet3, isNew: true },

  // Jewellery — Anklets
  { id: 'anklet-gold', name: 'Gold-Tone Anklet', description: 'A fine, adjustable gold-tone anklet for a touch of summer elegance.', price: 380, category: 'Jewellery', subcategory: 'Anklets', image: img.bracelet1, isNew: true },

  // Jewellery — Sets
  { id: 'set-jewellery-1', name: 'Gold Jewellery Set', description: 'A matching necklace and earring set in warm gold tones — the complete look, done.', price: 1500, category: 'Jewellery', subcategory: 'Jewellery Sets', image: img.earrings1, badge: 'Best Seller', isBestSeller: true },
  { id: 'set-pearl', name: 'Pearl Jewellery Set', description: 'A timeless pearl necklace and earring set — a gift that always feels right.', price: 1800, category: 'Jewellery', subcategory: 'Jewellery Sets', image: img.pearl1, badge: 'Featured' },
  { id: 'set-heart', name: 'Heart Pendant Jewellery Set', description: 'A sweet heart-themed necklace and earring set in a keepsake box.', price: 1300, category: 'Jewellery', subcategory: 'Jewellery Sets', image: img.earrings4 },

  // Bags & Wallets
  { id: 'bag-handbag-classic', name: 'Classic Leather Handbag', description: 'A structured leather-look handbag that carries your day beautifully.', price: 2500, category: 'Bags & Wallets', subcategory: 'Handbags', image: img.bag1, badge: 'Featured', isBestSeller: true },
  { id: 'bag-shoulder', name: 'Shoulder Bag', description: 'A soft, everyday shoulder bag with an adjustable strap and gold hardware.', price: 2200, category: 'Bags & Wallets', subcategory: 'Shoulder Bags', image: img.bag2, isNew: true },
  { id: 'bag-mini', name: 'Mini Bag', description: 'A compact mini bag for the essentials — chic and on-trend.', price: 1800, category: 'Bags & Wallets', subcategory: 'Mini Bags', image: img.bag3 },
  { id: 'bag-clutch', name: 'Evening Clutch', description: 'An elegant clutch for evenings out — sleek, minimal, and endlessly versatile.', price: 1500, category: 'Bags & Wallets', subcategory: 'Clutches', image: img.bag3, badge: 'New Arrival', isNew: true },
  { id: 'bag-crossbody', name: 'Crossbody Bag', description: 'A hands-free crossbody for everyday ease with a refined finish.', price: 2000, category: 'Bags & Wallets', subcategory: 'Crossbody Bags', image: img.bag1 },
  { id: 'bag-wallet', name: 'Leather Wallet', description: 'A slim, elegant wallet with card slots and a gold-tone clasp.', price: 1200, category: 'Bags & Wallets', subcategory: 'Wallets', image: img.bag2, collection: 'everyday-elegance' },

  // Makeup & Cosmetics
  { id: 'makeup-lipstick-red', name: 'Classic Red Lipstick', description: 'A rich, long-lasting red that makes every moment feel special.', price: 450, category: 'Makeup & Cosmetics', subcategory: 'Lipsticks', image: img.makeup3, badge: 'Best Seller', isBestSeller: true },
  { id: 'makeup-lipstick-nude', name: 'Nude Lipstick', description: 'A soft, everyday nude that suits every skin tone.', price: 450, category: 'Makeup & Cosmetics', subcategory: 'Lipsticks', image: img.makeup3, collection: 'everyday-elegance' },
  { id: 'makeup-lipgloss', name: 'Glossy Lip Gloss', description: 'A high-shine, non-sticky gloss for a fuller-looking pout.', price: 380, category: 'Makeup & Cosmetics', subcategory: 'Lip Gloss', image: img.makeup3, isNew: true },
  { id: 'makeup-blush', name: 'Soft Blush', description: 'A silky, blendable blush for a natural, healthy flush.', price: 520, category: 'Makeup & Cosmetics', subcategory: 'Blush', image: img.makeup2 },
  { id: 'makeup-mascara', name: 'Volumising Mascara', description: 'Lash-lengthening, smudge-proof mascara for all-day definition.', price: 600, category: 'Makeup & Cosmetics', subcategory: 'Mascara', image: img.makeup1 },
  { id: 'makeup-palette-eyes', name: 'Eyeshadow Palette', description: 'A curated palette of wearable neutrals and shimmering accents.', price: 950, category: 'Makeup & Cosmetics', subcategory: 'Makeup Palettes', image: img.makeupPal1, badge: 'Featured' },
  { id: 'makeup-palette-color', name: 'Colour Eyeshadow Palette', description: 'A bold, versatile palette for day and night looks.', price: 1100, category: 'Makeup & Cosmetics', subcategory: 'Makeup Palettes', image: img.makeupPal2, isNew: true },
  { id: 'makeup-brushes', name: 'Makeup Brush Set', description: 'A set of soft, dense brushes for a flawless, blended finish.', price: 850, category: 'Makeup & Cosmetics', subcategory: 'Makeup Brushes', image: img.makeupPal3, badge: 'Best Seller', isBestSeller: true },
  { id: 'makeup-beauty-tools', name: 'Beauty Tool Kit', description: 'Essential beauty tools for a complete at-home routine.', price: 980, category: 'Makeup & Cosmetics', subcategory: 'Beauty Tools', image: img.makeup1 },

  // Watches
  { id: 'watch-gold', name: 'Gold-Tone Elegant Watch', description: 'A refined gold-tone watch with a slim profile — quiet luxury on the wrist.', price: 2200, category: 'Watches', subcategory: 'Elegant Watches', image: img.watch1, badge: 'Featured', isBestSeller: true },
  { id: 'watch-leather', name: 'Leather-Strap Watch', description: 'A vintage-inspired leather-strap watch for timeless, everyday wear.', price: 1900, category: 'Watches', subcategory: 'Everyday Watches', image: img.watch2, collection: 'everyday-elegance' },
  { id: 'watch-minimal', name: 'Minimal Watch', description: 'A clean, minimal dial on a gold-tone mesh strap — less is more.', price: 1700, category: 'Watches', subcategory: 'Minimal Watches', image: img.watch3, isNew: true },
  { id: 'watch-fashion', name: 'Fashion Watch', description: 'A statement fashion watch that turns an outfit into a look.', price: 1500, category: 'Watches', subcategory: 'Fashion Watches', image: img.watch1 },

  // Sunglasses
  { id: 'sunglasses-cateye', name: 'Cat-Eye Sunglasses', description: 'Retro cat-eye frames with full UV protection — vintage charm, modern edge.', price: 1200, category: 'Sunglasses', subcategory: 'Cat-Eye Sunglasses', image: img.sunglasses1, badge: 'New Arrival', isNew: true },
  { id: 'sunglasses-oval', name: 'Oval Sunglasses', description: 'Soft oval frames that flatter every face shape.', price: 1100, category: 'Sunglasses', subcategory: 'Oval Sunglasses', image: img.sunglasses2 },
  { id: 'sunglasses-square', name: 'Square Sunglasses', description: 'Bold square frames for a confident, contemporary look.', price: 1150, category: 'Sunglasses', subcategory: 'Square Sunglasses', image: img.sunglasses3 },
  { id: 'sunglasses-classic', name: 'Classic Sunglasses', description: 'Timeless, versatile frames that go with everything in your wardrobe.', price: 1000, category: 'Sunglasses', subcategory: 'Classic Sunglasses', image: img.sunglasses1, badge: 'Best Seller', isBestSeller: true, collection: 'everyday-elegance' },

  // Hair Accessories
  { id: 'hair-claw-clip', name: 'Gold Claw Clip', description: 'A sturdy, elegant claw clip that holds all day in style.', price: 250, category: 'Hair Accessories', subcategory: 'Claw Clips', image: img.hair1, badge: 'Best Seller', isBestSeller: true, collection: 'everyday-elegance' },
  { id: 'hair-claw-pearl', name: 'Pearl Claw Clip', description: 'A pearl-accented claw clip for a soft, romantic touch.', price: 320, category: 'Hair Accessories', subcategory: 'Claw Clips', image: img.hair1, isNew: true },
  { id: 'hair-scrunchie', name: 'Silk-Feel Scrunchie', description: 'A soft scrunchie that\'s gentle on your hair and easy on the eyes.', price: 180, category: 'Hair Accessories', subcategory: 'Scrunchies', image: img.hair1, collection: 'everyday-elegance' },
  { id: 'hair-band', name: 'Padded Hairband', description: 'A comfortable padded hairband with a refined finish.', price: 290, category: 'Hair Accessories', subcategory: 'Hairbands', image: img.hair1 },
  { id: 'hair-bow', name: 'Satin Hair Bow', description: 'A sweet satin hair bow clip for a playful, feminine look.', price: 220, category: 'Hair Accessories', subcategory: 'Hair Bows', image: img.hair1, isNew: true },
  { id: 'hair-pins', name: 'Decorative Hair Pins Set', description: 'A set of decorative pins to add sparkle to any hairstyle.', price: 200, category: 'Hair Accessories', subcategory: 'Decorative Hair Pins', image: img.hair1 },

  // Perfumes & Fragrances
  { id: 'perfume-women', name: 'Signature Women\'s Perfume', description: 'A warm, floral signature scent that lingers beautifully.', price: 1800, category: 'Perfumes & Fragrances', subcategory: "Women's Perfumes", image: img.perfume1, badge: 'Featured', isBestSeller: true },
  { id: 'perfume-elegant', name: 'Elegant Eau de Parfum', description: 'A sophisticated, long-lasting fragrance for day and evening.', price: 2200, category: 'Perfumes & Fragrances', subcategory: "Women's Perfumes", image: img.perfume2, isNew: true },
  { id: 'perfume-body-mist', name: 'Body Mist', description: 'A light, refreshing body mist for an all-day soft scent.', price: 750, category: 'Perfumes & Fragrances', subcategory: 'Body Mists', image: img.perfume3, collection: 'everyday-elegance' },
  { id: 'perfume-gift-set', name: 'Fragrance Gift Set', description: 'A perfume and body lotion duo, beautifully boxed for gifting.', price: 2600, category: 'Perfumes & Fragrances', subcategory: 'Fragrance Gift Sets', image: img.perfume1, badge: 'Best Seller', isBestSeller: true },

  // Beauty & Nail Accessories
  { id: 'nails-press-on', name: 'Press-On Nail Set', description: 'Salon-style press-on nails in a flattering, reusable design.', price: 480, category: 'Beauty & Nail Accessories', subcategory: 'Press-On Nails', image: img.nailPouch3, badge: 'New Arrival', isNew: true },
  { id: 'nail-art', name: 'Nail Art Accessory Kit', description: 'A kit of decals, gems, and tools for creative nail art at home.', price: 350, category: 'Beauty & Nail Accessories', subcategory: 'Nail Art Accessories', image: img.nailPouch2 },
  { id: 'pouch-cosmetic', name: 'Cosmetic Pouch', description: 'A pretty, practical pouch to keep your beauty essentials organised.', price: 550, category: 'Beauty & Nail Accessories', subcategory: 'Cosmetic Pouches', image: img.nailPouch1, badge: 'Featured', collection: 'everyday-elegance' },
  { id: 'organizer-makeup', name: 'Makeup Organizer', description: 'A clear, tiered organizer to display and store your collection.', price: 890, category: 'Beauty & Nail Accessories', subcategory: 'Makeup Organizers', image: img.nailPouch1 },

  // Fashion Accessories
  { id: 'scarf-silk', name: 'Silk-Feel Scarf', description: 'A lightweight, silky scarf that adds a pop of colour and polish.', price: 650, category: 'Fashion Accessories', subcategory: 'Scarves', image: img.scarf3, badge: 'New Arrival', isNew: true },
  { id: 'scarf-printed', name: 'Printed Scarf', description: 'A beautifully printed scarf that elevates a simple outfit in seconds.', price: 590, category: 'Fashion Accessories', subcategory: 'Scarves', image: img.scarf1, collection: 'everyday-elegance' },
  { id: 'belt-women', name: 'Elegant Women\'s Belt', description: 'A slim, gold-buckled belt that defines the waist beautifully.', price: 720, category: 'Fashion Accessories', subcategory: 'Belts', image: img.scarf2 },
  { id: 'brooch-gold', name: 'Gold-Tone Brooch', description: 'A refined gold-tone brooch to pin on a scarf, coat, or lapel.', price: 480, category: 'Fashion Accessories', subcategory: 'Brooches', image: img.goldFlatlay3 },
  { id: 'fashion-acc-set', name: 'Fashion Accessory Set', description: 'A curated set of small accessories to mix, match, and layer.', price: 950, category: 'Fashion Accessories', subcategory: 'Fashion Accessories', image: img.scarf3, badge: 'Featured' },

  // Gifts & Gift Sets
  { id: 'gift-jewellery-box', name: 'Jewellery Gift Box', description: 'A curated jewellery gift box, beautifully presented and ready to give.', price: 1500, category: 'Gifts & Gift Sets', subcategory: 'Jewellery Gift Boxes', image: img.gift1, badge: 'Best Seller', isBestSeller: true },
  { id: 'gift-birthday', name: 'Birthday Gift Set', description: 'A thoughtful birthday gift set of accessories — a gift she\'ll treasure.', price: 1800, category: 'Gifts & Gift Sets', subcategory: 'Birthday Gifts', image: img.gift2, isNew: true },
  { id: 'gift-set-beauty', name: 'Beauty Gift Set', description: 'A pampering beauty gift set — lipstick, gloss, and a soft pouch.', price: 1600, category: 'Gifts & Gift Sets', subcategory: 'Gift Sets', image: img.gift3, badge: 'Featured' },
  { id: 'gift-occasion', name: 'Special Occasion Gift Set', description: 'An elegant occasion gift set for weddings, Eid, and celebrations.', price: 2200, category: 'Gifts & Gift Sets', subcategory: 'Special Occasion Gifts', image: img.gift1 },
  { id: 'gift-pearl-set', name: 'Pearl Gift Set', description: 'A timeless pearl jewellery set in a keepsake gift box.', price: 2000, category: 'Gifts & Gift Sets', subcategory: 'Gift Sets', image: img.pearl1, badge: 'Best Seller', isBestSeller: true },
];

export const categoryNames: CategoryName[] = [
  'Jewellery',
  'Bags & Wallets',
  'Makeup & Cosmetics',
  'Watches',
  'Sunglasses',
  'Hair Accessories',
  'Perfumes & Fragrances',
  'Beauty & Nail Accessories',
  'Fashion Accessories',
  'Gifts & Gift Sets',
];

export const formatPKR = (n: number) => `Rs. ${n.toLocaleString('en-PK')}`;

export function getProductById(id: string): Product | undefined {
  return products.find((p) => p.id === id);
}
