import { Heart, Eye, Plus } from 'lucide-react';
import { useState } from 'react';
import type { Product } from '@/data/products';
import { formatPKR } from '@/data/products';
import { useCart } from '@/context/CartContext';
import { useWishlist } from '@/context/WishlistContext';
import { ImageWithFallback } from './ImageWithFallback';

interface ProductCardProps {
  product: Product;
  onOpen: (id: string) => void;
}

export function ProductCard({ product, onOpen }: ProductCardProps) {
  const { addProduct } = useCart();
  const { has, toggle } = useWishlist();
  const [added, setAdded] = useState(false);
  const isWishlisted = has(product.id);

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    addProduct(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 1200);
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggle(product);
  };

  const handleQuickView = (e: React.MouseEvent) => {
    e.stopPropagation();
    onOpen(product.id);
  };

  const price = product.salePrice ?? product.price;
  const onSale = product.salePrice !== undefined;

  return (
    <article className="product-card group cursor-pointer" onClick={() => onOpen(product.id)}>
      <div className="product-image-wrap aspect-[4/5] rounded-sm">
        <ImageWithFallback src={product.image} alt={product.name} className="product-image" />

        {/* Badge */}
        {product.badge && (
          <span className={`badge ${product.badge === 'Sale' ? 'bg-gold text-espresso' : product.badge === 'New Arrival' ? 'bg-espresso text-ivory' : 'bg-ivory text-espresso'}`}>
            {product.badge}
          </span>
        )}

        {/* Quick actions overlay */}
        <div className="absolute top-3 right-3 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <button onClick={handleWishlist} aria-label="Add to wishlist" className={`w-9 h-9 flex items-center justify-center bg-ivory/90 backdrop-blur-sm transition-colors ${isWishlisted ? 'text-gold' : 'text-espresso hover:text-gold'}`}>
            <Heart size={15} strokeWidth={1.5} fill={isWishlisted ? 'currentColor' : 'none'} />
          </button>
          <button onClick={handleQuickView} aria-label="Quick view" className="w-9 h-9 flex items-center justify-center bg-ivory/90 backdrop-blur-sm text-espresso hover:text-gold transition-colors">
            <Eye size={15} strokeWidth={1.5} />
          </button>
        </div>

        {/* Add to cart slide-up bar */}
        <div className="absolute bottom-0 left-0 right-0 bg-espresso text-ivory py-3 px-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
          <button onClick={handleAdd} className="w-full flex items-center justify-center gap-2 text-[11px] uppercase tracking-widest-2 font-medium">
            {added ? 'Added!' : 'Add to Cart'} <Plus size={13} />
          </button>
        </div>
      </div>

      <div className="p-4 text-center">
        <p className="text-[9px] uppercase tracking-widest-2 text-gold mb-1.5">{product.category}</p>
        <h3 className="font-serif text-base md:text-lg text-espresso leading-tight mb-2">{product.name}</h3>
        <div className="flex items-center justify-center gap-2">
          {onSale && <span className="text-xs text-espresso-light/50 line-through">{formatPKR(product.price)}</span>}
          <span className="font-serif text-base text-espresso">{formatPKR(price)}</span>
        </div>
      </div>
    </article>
  );
}
