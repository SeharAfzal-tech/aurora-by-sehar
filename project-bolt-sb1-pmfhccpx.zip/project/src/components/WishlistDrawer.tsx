import { X, Heart, ShoppingBag } from 'lucide-react';
import { useWishlist } from '@/context/WishlistContext';
import { useCart } from '@/context/CartContext';
import { getProductById, formatPKR } from '@/data/products';
import { ImageWithFallback } from './ImageWithFallback';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenProduct: (id: string) => void;
}

export function WishlistDrawer({ isOpen, onClose, onOpenProduct }: WishlistDrawerProps) {
  const { ids, remove } = useWishlist();
  const { addProduct } = useCart();

  const items = ids.map((id) => getProductById(id)).filter(Boolean) as NonNullable<ReturnType<typeof getProductById>>[];

  return (
    <>
      <div
        className={`fixed inset-0 z-[60] bg-espresso-deep/50 backdrop-blur-sm transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
      />
      <aside
        className={`fixed top-0 right-0 z-[70] h-full w-full max-w-md bg-ivory shadow-2xl flex flex-col transition-transform duration-500 ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}
        style={{ transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)' }}
      >
        <div className="flex items-center justify-between px-6 py-5 border-b border-taupe/15">
          <div className="flex items-center gap-2.5">
            <Heart size={18} strokeWidth={1.5} className="text-gold" />
            <h2 className="font-serif text-2xl text-espresso">Wishlist</h2>
            {items.length > 0 && <span className="text-xs text-espresso-light">({items.length})</span>}
          </div>
          <button onClick={onClose} aria-label="Close" className="text-espresso-light hover:text-espresso transition-colors">
            <X size={22} strokeWidth={1.5} />
          </button>
        </div>

        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center px-6 gap-3">
            <Heart size={44} strokeWidth={1} className="text-gold/50" />
            <p className="font-serif text-2xl text-espresso">No favourites yet</p>
            <p className="text-sm text-espresso-light">Tap the heart on any product to save it here.</p>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
            {items.map((p) => (
              <div key={p.id} className="flex gap-4 bg-white p-3 shadow-sm">
                <button onClick={() => { onOpenProduct(p.id); onClose(); }} className="w-20 h-24 shrink-0 product-image-wrap">
                  <ImageWithFallback src={p.image} alt={p.name} className="product-image" />
                </button>
                <div className="flex-1 flex flex-col">
                  <h3 className="font-serif text-lg text-espresso leading-tight">{p.name}</h3>
                  <p className="text-[10px] uppercase tracking-widest-2 text-gold mt-0.5">{p.category}</p>
                  <span className="font-serif text-base text-espresso mt-1">{formatPKR(p.salePrice ?? p.price)}</span>
                  <div className="flex items-center gap-2 mt-auto">
                    <button onClick={() => addProduct(p)} className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 text-[10px] uppercase tracking-widest-2 font-medium bg-espresso text-ivory hover:bg-espresso-deep transition-colors">
                      <ShoppingBag size={13} /> Add to Bag
                    </button>
                    <button onClick={() => remove(p.id)} aria-label="Remove" className="px-3 py-2 border border-taupe/25 text-espresso-light hover:text-espresso transition-colors text-[10px] uppercase tracking-widest-2">
                      Remove
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </aside>
    </>
  );
}
