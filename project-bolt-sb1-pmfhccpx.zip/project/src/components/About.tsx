import { useReveal } from '@/hooks/useReveal';
import { ImageWithFallback } from './ImageWithFallback';

const ABOUT_IMG = 'https://images.pexels.com/photos/7248760/pexels-photo-7248760.jpeg?auto=compress&cs=tinysrgb&w=1200';
const ABOUT_IMG_2 = 'https://images.pexels.com/photos/6641219/pexels-photo-6641219.jpeg?auto=compress&cs=tinysrgb&w=800';

export function About() {
  const { ref, visible } = useReveal<HTMLDivElement>();

  return (
    <section id="about" className="py-20 md:py-28 bg-espresso text-ivory relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <div ref={ref} className={`reveal ${visible ? 'is-visible' : ''} grid lg:grid-cols-2 gap-12 lg:gap-20 items-center`}>
          <div className="grid grid-cols-2 gap-4">
            <div className="product-image-wrap aspect-[3/4] rounded-sm">
              <ImageWithFallback src={ABOUT_IMG} alt="Velora jewellery collection" className="product-image" />
            </div>
            <div className="product-image-wrap aspect-[3/4] mt-12 rounded-sm">
              <ImageWithFallback src={ABOUT_IMG_2} alt="Velora model" className="product-image" />
            </div>
          </div>

          <div>
            <p className="text-gold text-[11px] uppercase tracking-widest-2 mb-4">Our Story</p>
            <h2 className="font-serif text-4xl md:text-5xl text-ivory leading-[1.1] mb-6">
              Elegance in every detail, from Khanpur to you.
            </h2>
            <div className="space-y-5 text-ivory/75 leading-relaxed">
              <p>
                Velora by Sehar was born in Khanpur, Sindh, from a love of beautiful things — the kind
                of accessories that turn an ordinary day into a small celebration. We believe elegance
                isn't about price tags; it's about the thoughtful details that make you feel like yourself.
              </p>
              <p>
                Our boutique brings together jewellery, handbags, makeup, watches, fragrances, and gifts
                under one curated roof. Every piece is selected with care, chosen to be worn, loved, and
                shared — not kept in a drawer.
              </p>
              <p>
                Whether you're treating yourself or finding the perfect gift for someone you love, we
                promise the same thing: a world of beautiful things, and elegance in every detail.
              </p>
            </div>
            <div className="grid grid-cols-3 gap-6 mt-12 pt-8 border-t border-ivory/15">
              <div>
                <p className="font-serif text-3xl text-gold mb-1">10+</p>
                <p className="text-ivory/60 text-[10px] uppercase tracking-widest-2">Categories</p>
              </div>
              <div>
                <p className="font-serif text-3xl text-gold mb-1">60+</p>
                <p className="text-ivory/60 text-[10px] uppercase tracking-widest-2">Products</p>
              </div>
              <div>
                <p className="font-serif text-3xl text-gold mb-1">1</p>
                <p className="text-ivory/60 text-[10px] uppercase tracking-widest-2">Boutique</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
