import { products } from '@/data/products';
import { ProductCard } from './ProductCard';
import { useReveal } from '@/hooks/useReveal';

interface FeaturedProps {
  onOpenProduct: (id: string) => void;
  onViewAll?: () => void;
}

export function NewArrivals({ onOpenProduct, onViewAll }: FeaturedProps) {
  const { ref, visible } = useReveal<HTMLDivElement>();
  const items = products.filter((p) => p.isNew).slice(0, 8);

  return (
    <section className="py-20 md:py-28 bg-ivory">
      <div ref={ref} className={`reveal ${visible ? 'is-visible' : ''} max-w-7xl mx-auto px-5 md:px-8`}>
        <div className="text-center max-w-2xl mx-auto mb-12">
          <p className="section-eyebrow">Just In</p>
          <h2 className="section-title">New Arrivals</h2>
          <p className="section-subtitle mx-auto">The latest pieces to join the Velora boutique.</p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-5 md:gap-6">
          {items.map((p) => (
            <ProductCard key={p.id} product={p} onOpen={onOpenProduct} />
          ))}
        </div>

        {onViewAll && (
          <div className="text-center mt-10">
            <button onClick={onViewAll} className="btn-outline">View All New Arrivals</button>
          </div>
        )}
      </div>
    </section>
  );
}

export function BestSellers({ onOpenProduct, onViewAll }: FeaturedProps) {
  const { ref, visible } = useReveal<HTMLDivElement>();
  const items = products.filter((p) => p.isBestSeller).slice(0, 8);

  return (
    <section className="py-20 md:py-28 bg-cream">
      <div ref={ref} className={`reveal ${visible ? 'is-visible' : ''} max-w-7xl mx-auto px-5 md:px-8`}>
        <div className="text-center max-w-2xl mx-auto mb-12">
          <p className="section-eyebrow">Loved by Many</p>
          <h2 className="section-title">Best Sellers</h2>
          <p className="section-subtitle mx-auto">The pieces our customers come back for, again and again.</p>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-5 md:gap-6">
          {items.map((p) => (
            <ProductCard key={p.id} product={p} onOpen={onOpenProduct} />
          ))}
        </div>

        {onViewAll && (
          <div className="text-center mt-10">
            <button onClick={onViewAll} className="btn-outline">View All Best Sellers</button>
          </div>
        )}
      </div>
    </section>
  );
}
