import { useEffect, useState } from 'react';

interface ImageWithFallbackProps {
  src: string;
  alt: string;
  className?: string;
  fallbackClassName?: string;
}

export function ImageWithFallback({ src, alt, className = '', fallbackClassName = '' }: ImageWithFallbackProps) {
  const [status, setStatus] = useState<'loading' | 'loaded' | 'error'>('loading');

  useEffect(() => {
    setStatus('loading');
  }, [src]);

  return (
    <>
      {status === 'error' && (
        <div className={`flex items-center justify-center bg-cream ${fallbackClassName || className}`}>
          <span className="font-serif text-gold/50 text-lg italic">Velora</span>
        </div>
      )}
      <img
        src={src}
        alt={alt}
        loading="lazy"
        decoding="async"
        onLoad={() => setStatus('loaded')}
        onError={() => setStatus('error')}
        className={className}
        style={status === 'loading' ? { opacity: 0 } : undefined}
      />
    </>
  );
}
