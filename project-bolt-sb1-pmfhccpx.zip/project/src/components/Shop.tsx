import { Search, X, SlidersHorizontal } from 'lucide-react';
import { useMemo, useState, useEffect } from 'react';
import { products, categoryNames, type CategoryName } from '@/data/products';
import { ProductCard } from './ProductCard';

type SortOption = 'featured' | 'price-asc' | 'price-desc' | 'newest';

interface ShopProps {
  onOpenProduct: (id: string) => void;
  initialCategory?: CategoryName | 'All' | null;
  initialQuery?: string;
  title?: string;
  subtitle?: string;
  filterFn?: (p: typeof products[number]) => boolean;
}

const PRICE_BUCKETS = [
  { label: 'All Prices', min: 0, max: Infinity },
  { label: 'Under Rs. 500', min: 0, max: 499 },
  { label: 'Rs. 500 – 1,000', min: 500, max: 1000 },
  { label: 'Rs. 1,000 – 2,000', min: 1001, max: 2000 },
  { label: 'Over Rs. 2,000', min: 2001, max: Infinity },
];

export function Shop({ onOpenProduct, initialCategory = 'All', initialQuery = '', title, subtitle, filterFn }: ShopProps) {
  const [category, setCategory] = useState<CategoryName | 'All'>(initialCategory ?? 'All');
  const [query, setQuery] = useState(initialQuery);
  const [sort, setSort] = useState<SortOption>('featured');
  const [priceBucket, setPriceBucket] = useState(0);
  const [showFilters, setShowFilters] = useState(false);

  // Sync external prop changes
  useEffect(() => { if (initialCategory) setCategory(initialCategory); }, [initialCategory]);
  useEffect(() => { setQuery(initialQuery); }, [initialQuery]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const bucket = PRICE_BUCKETS[priceBucket];
    let result = products.filter((p) => {
      if (filterFn && !filterFn(p)) return false;
      if (category !== 'All' && p.category !== category) return false;
      if (q && !p.name.toLowerCase().includes(q) && !p.description.toLowerCase().includes(q)) return false;
      const price = p.salePrice ?? p.price;
      if (price < bucket.min || price > bucket.max) return false;
      return true;
    });

    switch (sort) {
      case 'price-asc': result = [...result].sort((a, b) => (a.salePrice ?? a.price) - (b.salePrice ?? b.price)); break;
      case 'price-desc': result = [...result].sort((a, b) => (b.salePrice ?? b.price) - (a.salePrice ?? a.price)); break;
      case 'newest': result = [...result].sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0)); break;
      default: result = [...result].sort((a, b) => (b.isBestSeller ? 1 : 0) - (a.isBestSeller ? 1 : 0)); break;
    }
    return result;
  }, [category, query, sort, priceBucket, filterFn]);

  const clearAll = () => {
    setCategory('All');
    setQuery('');
    setSort('featured');
    setPriceBucket(0);
  };

  const hasActiveFilters = category !== 'All' || query !== '' || sort !== 'featured' || priceBucket !== 0;

  return (
    <section className="pt-28 pb-20 min-h-screen bg-ivory">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-10">
          <p className="section-eyebrow">The Boutique</p>
          <h2 className="section-title">{title ?? 'Shop All'}</h2>
          <p className="section-subtitle mx-auto">{subtitle ?? 'Every piece in the Velora collection, in one beautiful place.'}</p>
        </div>

        {/* Search + sort bar */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search size={17} strokeWidth={1.5} className="absolute left-4 top-1/2 -translate-y-1/2 text-espresso-light/50" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search products by name..."
              className="input-field pl-11 pr-11"
            />
            {query && (
              <button onClick={() => setQuery('')} className="absolute right-4 top-1/2 -translate-y-1/2 text-espresso-light/50 hover:text-espresso">
                <X size={16} strokeWidth={1.5} />
              </button>
            )}
          </div>
          <div className="flex gap-3">
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as SortOption)}
              className="input-field cursor-pointer"
            >
              <option value="featured">Sort: Featured</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="newest">Newest First</option>
            </select>
            <button onClick={() => setShowFilters((s) => !s)} className="md:hidden btn-outline !px-4">
              <SlidersHorizontal size={15} /> Filters
            </button>
          </div>
        </div>

        {/* Category filter row */}
        <div className={`flex flex-wrap items-center gap-2.5 mb-3 ${showFilters ? 'block' : 'hidden md:flex'}`}>
          {(['All', ...categoryNames] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`filter-chip ${category === cat ? 'bg-espresso text-ivory border-espresso' : 'bg-ivory text-espresso border-taupe/25 hover:border-gold'}`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Price filter row */}
        <div className={`flex flex-wrap items-center gap-2.5 mb-6 ${showFilters ? 'block' : 'hidden md:flex'}`}>
          {PRICE_BUCKETS.map((b, i) => (
            <button
              key={b.label}
              onClick={() => setPriceBucket(i)}
              className={`filter-chip ${priceBucket === i ? 'bg-gold text-espresso border-gold' : 'bg-ivory text-espresso-light border-taupe/25 hover:border-gold'}`}
            >
              {b.label}
            </button>
          ))}
          {hasActiveFilters && (
            <button onClick={clearAll} className="text-[11px] uppercase tracking-widest-2 text-gold hover:text-espresso-deep transition-colors ml-2">
              Clear All ✕
            </button>
          )}
        </div>

        {/* Results count */}
        <p className="text-xs text-espresso-light/60 mb-6">{filtered.length} {filtered.length === 1 ? 'product' : 'products'}</p>

        {/* Grid */}
        {filtered.length === 0 ? (
          <div className="text-center py-20">
            <p className="font-serif text-2xl text-espresso mb-2">No products found</p>
            <p className="text-espresso-light text-sm mb-6">Try adjusting your filters or search.</p>
            <button onClick={clearAll} className="btn-outline">Clear Filters</button>
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 md:gap-6">
            {filtered.map((p) => (
              <ProductCard key={p.id} product={p} onOpen={onOpenProduct} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
