import { ArrowRight } from 'lucide-react';
import { heroImage, heroImageSecondary } from '@/data/products';

interface HeroProps {
  onShopCollection: () => void;
  onDiscoverNew: () => void;
}

export function Hero({ onShopCollection, onDiscoverNew }: HeroProps) {
  return (
    <section className="relative min-h-screen pt-[112px] flex items-center bg-ivory overflow-hidden">
      <div className="max-w-7xl mx-auto px-5 md:px-8 w-full grid lg:grid-cols-2 gap-10 lg:gap-16 items-center">
        {/* Left — copy */}
        <div className="relative z-10 text-center lg:text-left">
          <p className="text-gold text-[11px] uppercase tracking-widest-2 mb-5 animate-fade-in" style={{ animationDelay: '0.1s' }}>
            Introducing Velora by Sehar
          </p>
          <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl lg:text-7xl text-espresso leading-[1.05] mb-6 animate-fade-up opacity-0" style={{ animationDelay: '0.25s' }}>
            Your Elegance,<br />Your Signature.
          </h1>
          <p className="text-espresso-light/70 text-base md:text-lg leading-relaxed max-w-md mx-auto lg:mx-0 mb-9 animate-fade-up opacity-0" style={{ animationDelay: '0.5s' }}>
            Discover a thoughtfully curated world of beautiful jewellery, timeless accessories, and everyday essentials designed to make every moment feel special.
          </p>
          <div className="flex flex-col sm:flex-row items-center lg:items-start justify-center lg:justify-start gap-4 animate-fade-up opacity-0" style={{ animationDelay: '0.75s' }}>
            <button onClick={onShopCollection} className="btn-primary w-full sm:w-auto">
              Shop the Collection <ArrowRight size={14} />
            </button>
            <button onClick={onDiscoverNew} className="btn-outline w-full sm:w-auto">
              Discover New Arrivals
            </button>
          </div>

          {/* Trust stats */}
          <div className="hidden lg:flex items-center gap-8 mt-12 pt-8 border-t border-taupe/20 animate-fade-in" style={{ animationDelay: '1s' }}>
            <div>
              <p className="font-serif text-2xl text-gold">10+</p>
              <p className="text-[10px] uppercase tracking-widest-2 text-espresso-light/60">Categories</p>
            </div>
            <div>
              <p className="font-serif text-2xl text-gold">60+</p>
              <p className="text-[10px] uppercase tracking-widest-2 text-espresso-light/60">Products</p>
            </div>
            <div>
              <p className="font-serif text-2xl text-gold">100%</p>
              <p className="text-[10px] uppercase tracking-widest-2 text-espresso-light/60">Curated</p>
            </div>
          </div>
        </div>

        {/* Right — images */}
        <div className="relative hidden lg:block animate-scale-in opacity-0" style={{ animationDelay: '0.4s' }}>
          <div className="product-image-wrap aspect-[4/5] rounded-sm">
            <img src={heroImage} alt="Elegant jewellery and accessories" className="w-full h-full object-cover" />
          </div>
          <div className="absolute -bottom-8 -left-8 w-44 h-56 product-image-wrap rounded-sm border-4 border-ivory shadow-xl">
            <img src={heroImageSecondary} alt="Velora accessory detail" className="w-full h-full object-cover" />
          </div>
          {/* Gold accent dot */}
          <div className="absolute -top-4 -right-4 w-20 h-20 border border-gold/40 rounded-full flex items-center justify-center">
            <span className="font-serif text-xs text-gold uppercase tracking-widest text-center leading-tight">Velora<br />Sehar</span>
          </div>
        </div>

        {/* Mobile single image */}
        <div className="lg:hidden mt-4">
          <div className="product-image-wrap aspect-[4/5] max-w-sm mx-auto rounded-sm">
            <img src={heroImage} alt="Elegant jewellery and accessories" className="w-full h-full object-cover" />
          </div>
        </div>
      </div>

      {/* Subtle gold side accent */}
      <div className="absolute left-0 top-1/2 -translate-y-1/2 hidden xl:block w-1 h-40 bg-gold/30" />
    </section>
  );
}
