import { Search as SearchIcon, X } from 'lucide-react';
import { useMemo, useState } from 'react';
import { products, formatPKR } from '@/data/products';
import { ImageWithFallback } from './ImageWithFallback';

interface SearchModalProps {
  open: boolean;
  onClose: () => void;
  onPickProduct: (id: string) => void;
}

export function SearchModal({ open, onClose, onPickProduct }: SearchModalProps) {
  const [q, setQ] = useState('');

  const results = useMemo(() => {
    const query = q.trim().toLowerCase();
    if (!query) return [];
    return products
      .filter((p) => p.name.toLowerCase().includes(query) || p.category.toLowerCase().includes(query) || p.description.toLowerCase().includes(query))
      .slice(0, 8);
  }, [q]);

  if (!open) return null;

  const handlePick = (id: string) => {
    onPickProduct(id);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-start justify-center pt-28 px-5">
      <div className="absolute inset-0 bg-espresso-deep/60 backdrop-blur-sm" onClick={onClose} />
      <div className="relative w-full max-w-2xl bg-ivory shadow-2xl animate-scale-in">
        <div className="flex items-center gap-3 px-5 py-4 border-b border-taupe/15">
          <SearchIcon size={19} strokeWidth={1.5} className="text-espresso-light/50" />
          <input
            autoFocus
            type="text"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search for products..."
            className="flex-1 bg-transparent text-espresso placeholder:text-espresso-light/40 focus:outline-none text-base"
          />
          <button onClick={onClose} aria-label="Close" className="text-espresso-light hover:text-espresso">
            <X size={20} strokeWidth={1.5} />
          </button>
        </div>

        <div className="max-h-[60vh] overflow-y-auto">
          {q && results.length === 0 && (
            <p className="px-5 py-8 text-center text-espresso-light text-sm">No products found for "{q}".</p>
          )}
          {!q && (
            <p className="px-5 py-8 text-center text-espresso-light text-sm">Start typing to search across our entire boutique.</p>
          )}
          {results.map((p) => (
            <button
              key={p.id}
              onClick={() => handlePick(p.id)}
              className="w-full flex items-center gap-4 px-5 py-3 hover:bg-cream transition-colors text-left border-b border-taupe/5 last:border-0"
            >
              <div className="w-14 h-16 shrink-0 product-image-wrap">
                <ImageWithFallback src={p.image} alt={p.name} className="product-image" />
              </div>
              <div className="flex-1">
                <p className="font-serif text-lg text-espresso leading-tight">{p.name}</p>
                <p className="text-xs text-gold uppercase tracking-widest-2">{p.category}</p>
              </div>
              <span className="font-serif text-base text-espresso">{formatPKR(p.salePrice ?? p.price)}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
