import { useEffect, useState } from 'react';
import { Search, ShoppingBag, Menu, X, Heart } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { useWishlist } from '@/context/WishlistContext';

interface NavbarProps {
  onNavigate: (view: string) => void;
  onOpenSearch: () => void;
  onOpenWishlist: () => void;
  currentView: string;
}

const LINKS = [
  { label: 'Home', view: 'home' },
  { label: 'Shop', view: 'shop' },
  { label: 'Collections', view: 'collections' },
  { label: 'New Arrivals', view: 'new-arrivals' },
  { label: 'Best Sellers', view: 'best-sellers' },
  { label: 'About Us', view: 'about' },
  { label: 'Contact', view: 'contact' },
];

export function Navbar({ onNavigate, onOpenSearch, onOpenWishlist, currentView }: NavbarProps) {
  const { count, openCart } = useCart();
  const { count: wishlistCount } = useWishlist();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 30);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const go = (view: string) => {
    onNavigate(view);
    setMobileOpen(false);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled ? 'bg-ivory/95 backdrop-blur-md shadow-[0_1px_0_rgba(53,41,31,0.06)]' : 'bg-ivory/80 backdrop-blur-sm'
      }`}
    >
      {/* Announcement bar */}
      <div className="bg-espresso text-ivory text-[10px] uppercase tracking-widest-2 text-center py-2 px-4">
        Free delivery on orders over Rs. 3,000 — Khanpur &amp; across Sindh
      </div>

      <nav className="max-w-7xl mx-auto px-5 md:px-8 flex items-center justify-between h-20">
        {/* Logo */}
        <button onClick={() => go('home')} className="flex items-center shrink-0 group">
          <img
            src="/Velora.png"
            alt="Velora by Sehar"
            className="h-14 w-14 md:h-16 md:w-16 object-contain transition-transform duration-300 group-hover:scale-105"
          />
          <div className="flex flex-col leading-none ml-2 md:ml-3">
            <span className="font-serif text-xl md:text-2xl tracking-wide text-espresso">VELORA</span>
            <span className="text-[8px] md:text-[9px] tracking-widest-2 uppercase text-gold mt-0.5">by Sehar</span>
          </div>
        </button>

        {/* Desktop links */}
        <ul className="hidden lg:flex items-center gap-7">
          {LINKS.map((l) => (
            <li key={l.view}>
              <button
                onClick={() => go(l.view)}
                className={`text-[11px] uppercase tracking-widest-2 font-medium transition-colors duration-300 relative group ${
                  currentView === l.view ? 'text-gold' : 'text-espresso hover:text-gold'
                }`}
              >
                {l.label}
                <span className={`absolute -bottom-1.5 left-0 h-px bg-gold transition-all duration-300 ${currentView === l.view ? 'w-full' : 'w-0 group-hover:w-full'}`} />
              </button>
            </li>
          ))}
        </ul>

        {/* Right cluster */}
        <div className="flex items-center gap-3 md:gap-4">
          <button onClick={onOpenSearch} aria-label="Search" className="p-1.5 text-espresso hover:text-gold transition-colors">
            <Search size={19} strokeWidth={1.5} />
          </button>

          <button onClick={onOpenWishlist} aria-label="Wishlist" className="relative p-1.5 text-espresso hover:text-gold transition-colors">
            <Heart size={19} strokeWidth={1.5} />
            {wishlistCount > 0 && (
              <span className="absolute -top-1 -right-1.5 bg-gold text-espresso text-[10px] font-semibold min-w-[16px] h-[16px] flex items-center justify-center rounded-full px-1">
                {wishlistCount}
              </span>
            )}
          </button>

          <button onClick={openCart} aria-label="Shopping bag" className="relative p-1.5 text-espresso hover:text-gold transition-colors">
            <ShoppingBag size={19} strokeWidth={1.5} />
            {count > 0 && (
              <span className="absolute -top-1 -right-1.5 bg-espresso text-ivory text-[10px] font-semibold min-w-[16px] h-[16px] flex items-center justify-center rounded-full px-1">
                {count}
              </span>
            )}
          </button>

          <button onClick={() => go('shop')} className="hidden md:inline-flex btn-gold !py-2.5 !px-6">
            Shop Now
          </button>

          {/* Mobile hamburger */}
          <button onClick={() => setMobileOpen((o) => !o)} aria-label="Menu" className="lg:hidden p-1.5 text-espresso">
            {mobileOpen ? <X size={22} strokeWidth={1.5} /> : <Menu size={22} strokeWidth={1.5} />}
          </button>
        </div>
      </nav>

      {/* Mobile drawer */}
      <div className={`lg:hidden overflow-hidden transition-all duration-500 bg-ivory border-t border-taupe/10 ${mobileOpen ? 'max-h-[500px]' : 'max-h-0'}`}>
        <ul className="px-6 py-4 flex flex-col">
          {LINKS.map((l) => (
            <li key={l.view}>
              <button onClick={() => go(l.view)} className={`w-full text-left py-3 text-xs uppercase tracking-widest-2 border-b border-taupe/5 ${currentView === l.view ? 'text-gold' : 'text-espresso-light'}`}>
                {l.label}
              </button>
            </li>
          ))}
          <li>
            <button onClick={() => go('shop')} className="btn-gold w-full mt-4">Shop Now</button>
          </li>
        </ul>
      </div>
    </header>
  );
}
