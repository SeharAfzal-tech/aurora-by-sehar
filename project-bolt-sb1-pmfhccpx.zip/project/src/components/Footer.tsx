import { Instagram, Facebook } from 'lucide-react';

interface FooterProps {
  onNavigate: (view: string) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  const shopLinks = ['Shop All', 'New Arrivals', 'Best Sellers', 'Collections', 'Gifts & Gift Sets'];
  const helpLinks = ['About Us', 'Contact', 'Shipping & Delivery', 'Returns', 'FAQ'];
  const categoryLinks = ['Jewellery', 'Bags & Wallets', 'Makeup & Cosmetics', 'Watches', 'Perfumes & Fragrances'];

  const handleNav = (label: string) => {
    const map: Record<string, string> = {
      'Shop All': 'shop',
      'New Arrivals': 'new-arrivals',
      'Best Sellers': 'best-sellers',
      'Collections': 'collections',
      'Gifts & Gift Sets': 'shop',
      'About Us': 'about',
      'Contact': 'contact',
    };
    onNavigate(map[label] ?? 'home');
  };

  return (
    <footer className="bg-espresso-deep text-ivory/80">
      <div className="max-w-7xl mx-auto px-5 md:px-8 py-16">
        <div className="grid md:grid-cols-4 gap-10">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center mb-5">
              <img src="/Velora.png" alt="Velora by Sehar" className="h-16 w-16 object-contain" />
              <div className="flex flex-col leading-none ml-3">
                <span className="font-serif text-xl text-ivory">VELORA</span>
                <span className="text-[9px] tracking-widest-2 uppercase text-gold mt-0.5">by Sehar</span>
              </div>
            </div>
            <p className="text-sm leading-relaxed text-ivory/55 max-w-xs">
              Elegance in every detail. A premium women's lifestyle boutique from Khanpur, Sindh — jewellery, fashion, beauty, and beautiful gifts.
            </p>
            <div className="flex gap-3 mt-5">
              <a href="#" aria-label="Instagram" className="w-10 h-10 border border-ivory/20 flex items-center justify-center hover:bg-gold hover:text-espresso transition-colors">
                <Instagram size={16} strokeWidth={1.5} />
              </a>
              <a href="#" aria-label="Facebook" className="w-10 h-10 border border-ivory/20 flex items-center justify-center hover:bg-gold hover:text-espresso transition-colors">
                <Facebook size={16} strokeWidth={1.5} />
              </a>
            </div>
          </div>

          {/* Shop */}
          <div>
            <h4 className="text-[11px] uppercase tracking-widest-2 text-gold mb-4">Shop</h4>
            <ul className="space-y-2.5 text-sm">
              {shopLinks.map((l) => (
                <li key={l}><button onClick={() => handleNav(l)} className="hover:text-gold transition-colors text-left">{l}</button></li>
              ))}
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-[11px] uppercase tracking-widest-2 text-gold mb-4">Categories</h4>
            <ul className="space-y-2.5 text-sm">
              {categoryLinks.map((l) => (
                <li key={l}><button onClick={() => onNavigate('shop')} className="hover:text-gold transition-colors text-left">{l}</button></li>
              ))}
            </ul>
          </div>

          {/* Help */}
          <div>
            <h4 className="text-[11px] uppercase tracking-widest-2 text-gold mb-4">Help</h4>
            <ul className="space-y-2.5 text-sm">
              {helpLinks.map((l) => (
                <li key={l}><button onClick={() => handleNav(l)} className="hover:text-gold transition-colors text-left">{l}</button></li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-14 pt-6 border-t border-ivory/10 flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-ivory/40">
          <p>© {new Date().getFullYear()} Velora by Sehar. All rights reserved.</p>
          <p>Elegance in Every Detail — Khanpur, Sindh, Pakistan.</p>
        </div>
      </div>
    </footer>
  );
}
