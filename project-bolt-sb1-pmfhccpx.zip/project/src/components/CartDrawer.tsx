import { X, Plus, Minus, Trash2, ShoppingBag, ArrowRight } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { formatPKR } from '@/data/products';
import { ImageWithFallback } from './ImageWithFallback';

interface CartDrawerProps {
  onCheckout: () => void;
  onContinue: () => void;
}

export function CartDrawer({ onCheckout, onContinue }: CartDrawerProps) {
  const { lines, isOpen, closeCart, increment, decrement, remove, subtotal, count } = useCart();

  return (
    <>
      <div
        className={`fixed inset-0 z-[60] bg-espresso-deep/50 backdrop-blur-sm transition-opacity duration-300 ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
        onClick={closeCart}
      />
      <aside
        className={`fixed top-0 right-0 z-[70] h-full w-full max-w-md bg-ivory shadow-2xl flex flex-col transition-transform duration-500 ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}
        style={{ transitionTimingFunction: 'cubic-bezier(0.16, 1, 0.3, 1)' }}
      >
        <div className="flex items-center justify-between px-6 py-5 border-b border-taupe/15">
          <div className="flex items-center gap-2.5">
            <ShoppingBag size={18} strokeWidth={1.5} className="text-espresso" />
            <h2 className="font-serif text-2xl text-espresso">Your Bag</h2>
            {count > 0 && <span className="text-xs text-espresso-light">({count})</span>}
          </div>
          <button onClick={closeCart} aria-label="Close" className="text-espresso-light hover:text-espresso transition-colors">
            <X size={22} strokeWidth={1.5} />
          </button>
        </div>

        {lines.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center text-center px-6 gap-3">
            <ShoppingBag size={44} strokeWidth={1} className="text-gold/50" />
            <p className="font-serif text-2xl text-espresso">Your bag is empty</p>
            <p className="text-sm text-espresso-light">Add a few pieces and they'll appear here.</p>
            <button onClick={onContinue} className="btn-outline mt-3">Explore the Shop</button>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
              {lines.map((line) => (
                <div key={line.id} className="flex gap-4 bg-white p-3 shadow-sm">
                  <div className="w-20 h-24 shrink-0 product-image-wrap">
                    <ImageWithFallback src={line.image} alt={line.name} className="product-image" />
                  </div>
                  <div className="flex-1 flex flex-col">
                    <div className="flex items-start justify-between gap-2">
                      <h3 className="font-serif text-lg text-espresso leading-tight">{line.name}</h3>
                      <button onClick={() => remove(line.id)} aria-label="Remove" className="text-espresso-light/40 hover:text-espresso transition-colors">
                        <Trash2 size={15} strokeWidth={1.5} />
                      </button>
                    </div>
                    <div className="flex items-center justify-between mt-auto">
                      <div className="flex items-center gap-2 border border-taupe/25">
                        <button onClick={() => decrement(line.id)} aria-label="Decrease" className="w-7 h-7 flex items-center justify-center text-espresso hover:bg-cream transition-colors">
                          <Minus size={13} />
                        </button>
                        <span className="text-sm text-espresso w-6 text-center">{line.quantity}</span>
                        <button onClick={() => increment(line.id)} aria-label="Increase" className="w-7 h-7 flex items-center justify-center text-espresso hover:bg-cream transition-colors">
                          <Plus size={13} />
                        </button>
                      </div>
                      <span className="font-serif text-base text-espresso">{formatPKR(line.price * line.quantity)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="border-t border-taupe/15 px-6 py-5 bg-white">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm uppercase tracking-widest-2 text-espresso-light">Subtotal</span>
                <span className="font-serif text-2xl text-espresso">{formatPKR(subtotal)}</span>
              </div>
              <p className="text-xs text-espresso-light/60 mb-5">Delivery & taxes calculated at checkout.</p>
              <button onClick={onCheckout} className="btn-primary w-full mb-2">
                Proceed to Checkout <ArrowRight size={14} />
              </button>
              <button onClick={closeCart} className="w-full text-xs uppercase tracking-widest-2 text-espresso-light hover:text-espresso transition-colors py-2">
                Continue Shopping
              </button>
            </div>
          </>
        )}
      </aside>
    </>
  );
}
