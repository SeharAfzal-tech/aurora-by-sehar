import { useState, useMemo } from 'react';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import { collections, products, formatPKR, type Product } from '@/data/products';
import { useReveal } from '@/hooks/useReveal';
import { ImageWithFallback } from './ImageWithFallback';
import { ProductCard } from './ProductCard';

interface CollectionsProps {
  initialCollection?: string | null;
  onOpenProduct: (id: string) => void;
}

export function Collections({ initialCollection, onOpenProduct }: CollectionsProps) {
  const [active, setActive] = useState<string | null>(initialCollection ?? null);
  const activeCollection = active ? collections.find((c) => c.id === active) : null;

  if (activeCollection) {
    return (
      <CollectionDetail
        collection={activeCollection}
        onBack={() => setActive(null)}
        onOpenProduct={onOpenProduct}
      />
    );
  }

  return (
    <section id="collections" className="py-20 md:py-28 bg-cream">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <p className="section-eyebrow">Curated for You</p>
          <h2 className="section-title">Premium Collections</h2>
          <p className="section-subtitle mx-auto">Thoughtfully themed edits for every mood and moment.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-6">
          {collections.map((col, i) => (
            <CollectionCard key={col.id} col={col} index={i} onOpen={() => setActive(col.id)} />
          ))}
        </div>
      </div>
    </section>
  );
}

function CollectionCard({ col, index, onOpen }: { col: typeof collections[number]; index: number; onOpen: () => void }) {
  const { ref, visible } = useReveal<HTMLButtonElement>();
  const isWide = index % 5 === 0;

  return (
    <button
      ref={ref}
      onClick={onOpen}
      className={`reveal ${visible ? 'is-visible' : ''} group relative overflow-hidden text-left ${isWide ? 'md:col-span-2' : ''}`}
      style={{ transitionDelay: `${(index % 3) * 80}ms` }}
    >
      <div className={`product-image-wrap ${isWide ? 'aspect-[16/9]' : 'aspect-[4/5]'} rounded-sm`}>
        <ImageWithFallback src={col.image} alt={col.title} className="product-image" />
        <div className="absolute inset-0 bg-gradient-to-t from-espresso-deep/85 via-espresso/15 to-transparent transition-opacity duration-500 group-hover:from-espresso-deep/95" />
      </div>
      <div className="absolute bottom-0 left-0 right-0 p-6 text-ivory">
        <p className="text-gold-light text-[10px] uppercase tracking-widest-2 mb-1.5">{col.subtitle}</p>
        <h3 className="font-serif text-2xl md:text-3xl mb-2">{col.title}</h3>
        <p className="text-ivory/70 text-sm leading-snug max-w-md mb-3 hidden md:block">{col.description}</p>
        <span className="inline-flex items-center gap-1.5 text-[11px] uppercase tracking-widest-2 text-ivory group-hover:text-gold-light transition-colors">
          Explore Collection <ArrowRight size={13} />
        </span>
      </div>
    </button>
  );
}

function CollectionDetail({ collection, onBack, onOpenProduct }: { collection: typeof collections[number]; onBack: () => void; onOpenProduct: (id: string) => void }) {
  const items = useMemo(() => products.filter(collection.filter), [collection]);
  const { ref, visible } = useReveal<HTMLDivElement>();

  return (
    <div ref={ref} className={`reveal ${visible ? 'is-visible' : ''}`}>
      <div className="relative h-[38vh] min-h-[260px] overflow-hidden">
        <ImageWithFallback src={collection.image} alt={collection.title} className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-espresso-deep/70 to-espresso-deep/85" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center text-ivory px-6">
          <p className="text-gold-light text-[11px] uppercase tracking-widest-2 mb-3">{collection.subtitle}</p>
          <h2 className="font-serif text-3xl md:text-5xl mb-3">{collection.title}</h2>
          <p className="text-ivory/80 max-w-xl">{collection.description}</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-5 md:px-8 py-14">
        <button onClick={onBack} className="inline-flex items-center gap-2 text-xs uppercase tracking-widest-2 text-espresso hover:text-gold transition-colors mb-10">
          <ArrowLeft size={15} /> All Collections
        </button>

        {items.length === 0 ? (
          <p className="text-center text-espresso-light py-16">No products in this collection yet.</p>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-5 md:gap-6">
            {items.map((p) => (
              <ProductCard key={p.id} product={p} onOpen={onOpenProduct} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
