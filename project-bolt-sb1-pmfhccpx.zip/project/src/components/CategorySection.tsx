import { categories } from '@/data/products';
import { useReveal } from '@/hooks/useReveal';
import { ImageWithFallback } from './ImageWithFallback';

interface CategorySectionProps {
  onShopCategory: (category: string) => void;
}

export function CategorySection({ onShopCategory }: CategorySectionProps) {
  return (
    <section className="py-20 md:py-28 bg-ivory">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <p className="section-eyebrow">Find Your Style</p>
          <h2 className="section-title">Explore Your Style</h2>
          <p className="section-subtitle mx-auto">Everything you love, beautifully curated.</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
          {categories.map((cat, i) => (
            <CategoryCard key={cat.name} cat={cat} index={i} onClick={() => onShopCategory(cat.name)} />
          ))}
        </div>
      </div>
    </section>
  );
}

function CategoryCard({ cat, index, onClick }: { cat: typeof categories[number]; index: number; onClick: () => void }) {
  const { ref, visible } = useReveal<HTMLButtonElement>();
  const isLarge = index === 0 || index === 5;

  return (
    <button
      ref={ref}
      onClick={onClick}
      className={`reveal ${visible ? 'is-visible' : ''} group relative overflow-hidden text-left ${isLarge ? 'md:col-span-2 md:row-span-1' : ''}`}
      style={{ transitionDelay: `${(index % 4) * 70}ms` }}
    >
      <div className={`product-image-wrap ${isLarge ? 'aspect-[2/1] md:aspect-[2/1]' : 'aspect-[4/5]'} rounded-sm`}>
        <ImageWithFallback src={cat.image} alt={cat.name} className="product-image" />
        <div className="absolute inset-0 bg-gradient-to-t from-espresso-deep/80 via-espresso/10 to-transparent transition-opacity duration-500 group-hover:from-espresso-deep/90" />
      </div>
      <div className="absolute bottom-0 left-0 right-0 p-5 md:p-6 text-ivory">
        <h3 className="font-serif text-xl md:text-2xl mb-1">{cat.name}</h3>
        <p className="text-ivory/70 text-xs hidden md:block mb-3">{cat.description}</p>
        <span className="inline-flex items-center gap-1.5 text-[10px] uppercase tracking-widest-2 text-ivory group-hover:text-gold-light transition-colors">
          Shop Now →
        </span>
      </div>
    </button>
  );
}
