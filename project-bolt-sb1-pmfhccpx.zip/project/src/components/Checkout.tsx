import { useState } from 'react';
import { ArrowLeft, Check, ShoppingBag, Loader2, Truck } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { formatPKR } from '@/data/products';
import { supabase } from '@/lib/supabase';
import { ImageWithFallback } from './ImageWithFallback';

interface CheckoutProps {
  onBack: () => void;
  onHome: () => void;
}

const DELIVERY_FEE = 150;
const FREE_DELIVERY_THRESHOLD = 3000;

export function Checkout({ onBack, onHome }: CheckoutProps) {
  const { lines, subtotal, clear } = useCart();
  const deliveryFee = subtotal >= FREE_DELIVERY_THRESHOLD ? 0 : DELIVERY_FEE;
  const total = subtotal + (lines.length ? deliveryFee : 0);

  const [form, setForm] = useState({ name: '', phone: '', address: '', city: 'Khanpur', notes: '' });
  const [status, setStatus] = useState<'idle' | 'submitting' | 'success' | 'error'>('idle');
  const [orderId, setOrderId] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (lines.length === 0) return;
    setStatus('submitting');
    setErrorMsg('');

    try {
      const { data, error } = await supabase
        .from('velora_orders')
        .insert({
          customer_name: form.name,
          phone: form.phone,
          address: form.address,
          city: form.city,
          notes: form.notes || null,
          items: lines.map((l) => ({ name: l.name, price: l.price, quantity: l.quantity, image: l.image })),
          subtotal,
          delivery_fee: deliveryFee,
          total,
          status: 'received',
        })
        .select('id')
        .single();

      if (error) throw new Error(error.message);
      setOrderId(data.id);
      setStatus('success');
      clear();
    } catch (err) {
      setStatus('error');
      setErrorMsg(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
    }
  };

  if (status === 'success') {
    return (
      <section className="pt-32 pb-24 min-h-screen bg-ivory flex items-center">
        <div className="max-w-lg mx-auto px-6 text-center">
          <div className="w-20 h-20 rounded-full bg-espresso text-ivory flex items-center justify-center mx-auto mb-6">
            <Check size={36} strokeWidth={1.5} />
          </div>
          <p className="section-eyebrow">Order Placed</p>
          <h2 className="font-serif text-4xl text-espresso mb-4">Thank you, {form.name.split(' ')[0] || 'dear'}.</h2>
          <p className="text-espresso-light leading-relaxed mb-2">
            Your order has been received and is being prepared. We'll call you shortly on{' '}
            <span className="text-espresso font-medium">{form.phone}</span> to confirm.
          </p>
          {orderId && <p className="text-xs uppercase tracking-widest-2 text-gold mb-8">Order Ref: {orderId.slice(0, 8).toUpperCase()}</p>}
          <button onClick={onHome} className="btn-primary">Back to Home</button>
        </div>
      </section>
    );
  }

  if (lines.length === 0) {
    return (
      <section className="pt-32 pb-24 min-h-screen bg-ivory flex items-center">
        <div className="max-w-lg mx-auto px-6 text-center">
          <ShoppingBag size={48} strokeWidth={1} className="text-gold/50 mx-auto mb-5" />
          <h2 className="font-serif text-3xl text-espresso mb-3">Your bag is empty</h2>
          <p className="text-espresso-light mb-6">Add a few pieces before heading to checkout.</p>
          <button onClick={onBack} className="btn-primary">Browse the Shop</button>
        </div>
      </section>
    );
  }

  return (
    <section className="pt-28 pb-20 min-h-screen bg-ivory">
      <div className="max-w-6xl mx-auto px-5 md:px-8">
        <button onClick={onBack} className="inline-flex items-center gap-2 text-xs uppercase tracking-widest-2 text-espresso hover:text-gold transition-colors mb-8">
          <ArrowLeft size={15} /> Back to Shop
        </button>

        <div className="grid lg:grid-cols-5 gap-10">
          <form onSubmit={onSubmit} className="lg:col-span-3 bg-white p-7 md:p-9 shadow-[0_2px_20px_rgba(53,41,31,0.06)] space-y-5">
            <h2 className="font-serif text-3xl text-espresso mb-2">Checkout</h2>
            <p className="text-sm text-espresso-light mb-6">Enter your details and we'll prepare your order right away.</p>

            <div className="grid sm:grid-cols-2 gap-5">
              <Field label="Full Name"><input type="text" required value={form.name} onChange={set('name')} className="input-field" placeholder="Your name" /></Field>
              <Field label="Phone Number"><input type="tel" required value={form.phone} onChange={set('phone')} className="input-field" placeholder="03xx xxxxxxx" /></Field>
            </div>
            <Field label="Delivery Address"><input type="text" required value={form.address} onChange={set('address')} className="input-field" placeholder="House #, street, area" /></Field>
            <Field label="City"><input type="text" required value={form.city} onChange={set('city')} className="input-field" placeholder="City" /></Field>
            <Field label="Order Notes (optional)"><textarea rows={3} value={form.notes} onChange={set('notes')} className="input-field resize-none" placeholder="Delivery instructions, etc." /></Field>

            {status === 'error' && <p className="text-sm text-red-700 bg-red-50 border border-red-100 px-4 py-3">{errorMsg}</p>}

            <button type="submit" disabled={status === 'submitting'} className="btn-primary w-full disabled:opacity-60">
              {status === 'submitting' ? <><Loader2 size={15} className="animate-spin" /> Placing Order…</> : <>Place Order — {formatPKR(total)}</>}
            </button>
          </form>

          <aside className="lg:col-span-2">
            <div className="bg-white p-7 shadow-[0_2px_20px_rgba(53,41,31,0.06)] sticky top-28">
              <h3 className="font-serif text-2xl text-espresso mb-5">Order Summary</h3>
              <div className="space-y-4 max-h-80 overflow-y-auto pr-1 mb-5">
                {lines.map((l) => (
                  <div key={l.id} className="flex gap-3 items-center">
                    <div className="w-14 h-16 shrink-0 product-image-wrap">
                      <ImageWithFallback src={l.image} alt={l.name} className="product-image" />
                    </div>
                    <div className="flex-1">
                      <p className="font-serif text-base text-espresso leading-tight">{l.name}</p>
                      <p className="text-xs text-espresso-light">Qty {l.quantity} × {formatPKR(l.price)}</p>
                    </div>
                    <span className="font-serif text-sm text-espresso">{formatPKR(l.price * l.quantity)}</span>
                  </div>
                ))}
              </div>
              <div className="border-t border-taupe/15 pt-4 space-y-2 text-sm">
                <Row label="Subtotal" value={formatPKR(subtotal)} />
                <Row label="Delivery Fee" value={deliveryFee === 0 ? 'Free' : formatPKR(deliveryFee)} />
                {subtotal < FREE_DELIVERY_THRESHOLD && (
                  <p className="text-xs text-gold flex items-center gap-1.5 pt-1">
                    <Truck size={13} /> Add {formatPKR(FREE_DELIVERY_THRESHOLD - subtotal)} more for free delivery
                  </p>
                )}
                <div className="flex items-center justify-between pt-2 mt-2 border-t border-taupe/15">
                  <span className="font-serif text-lg text-espresso">Total</span>
                  <span className="font-serif text-xl text-espresso">{formatPKR(total)}</span>
                </div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="block text-[11px] uppercase tracking-widest-2 text-espresso-light mb-2">{label}</span>
      {children}
    </label>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between text-espresso-light">
      <span>{label}</span>
      <span className="text-espresso">{value}</span>
    </div>
  );
}
