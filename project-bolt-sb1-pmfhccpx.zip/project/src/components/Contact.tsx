import { useState } from 'react';
import { MapPin, Phone, Clock, Mail, Send, Instagram, Facebook } from 'lucide-react';
import { useReveal } from '@/hooks/useReveal';

export function Contact() {
  const { ref, visible } = useReveal<HTMLDivElement>();
  const [sent, setSent] = useState(false);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
    setTimeout(() => setSent(false), 4000);
  };

  const info = [
    { icon: MapPin, label: 'Visit', value: 'Velora by Sehar, Khanpur, Sindh, Pakistan' },
    { icon: Phone, label: 'Call', value: '+92 300 1234567' },
    { icon: Clock, label: 'Hours', value: '10:00 AM – 9:00 PM, Daily' },
    { icon: Mail, label: 'Email', value: 'hello@velorabysehar.com' },
  ];

  return (
    <section id="contact" className="py-20 md:py-28 bg-cream">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <p className="section-eyebrow">We'd Love to Hear from You</p>
          <h2 className="section-title">Get in Touch</h2>
          <p className="section-subtitle mx-auto">Questions, orders, or just saying hello — we're here.</p>
        </div>

        <div ref={ref} className={`reveal ${visible ? 'is-visible' : ''} grid lg:grid-cols-2 gap-12 lg:gap-16`}>
          <div className="space-y-8">
            {info.map((item) => (
              <div key={item.label} className="flex items-start gap-4">
                <div className="w-12 h-12 flex items-center justify-center bg-espresso text-ivory shrink-0">
                  <item.icon size={19} strokeWidth={1.5} />
                </div>
                <div>
                  <p className="text-[11px] uppercase tracking-widest-2 text-gold mb-1">{item.label}</p>
                  <p className="text-espresso leading-relaxed">{item.value}</p>
                </div>
              </div>
            ))}
            <div className="pt-4">
              <p className="text-[11px] uppercase tracking-widest-2 text-gold mb-3">Follow Velora</p>
              <div className="flex gap-3">
                <a href="#" aria-label="Instagram" className="w-11 h-11 border border-taupe/30 flex items-center justify-center text-espresso hover:bg-espresso hover:text-ivory transition-colors">
                  <Instagram size={16} strokeWidth={1.5} />
                </a>
                <a href="#" aria-label="Facebook" className="w-11 h-11 border border-taupe/30 flex items-center justify-center text-espresso hover:bg-espresso hover:text-ivory transition-colors">
                  <Facebook size={16} strokeWidth={1.5} />
                </a>
              </div>
            </div>
          </div>

          <form onSubmit={onSubmit} className="bg-ivory p-8 md:p-10 shadow-[0_2px_20px_rgba(53,41,31,0.06)] space-y-5">
            <div className="grid sm:grid-cols-2 gap-5">
              <Field label="Your Name">
                <input type="text" required className="input-field" />
              </Field>
              <Field label="Phone">
                <input type="tel" required className="input-field" />
              </Field>
            </div>
            <Field label="Email">
              <input type="email" required className="input-field" />
            </Field>
            <Field label="Message">
              <textarea rows={4} required className="input-field resize-none" />
            </Field>
            <button type="submit" className="btn-primary w-full">
              {sent ? 'Message Sent' : 'Send Message'} <Send size={14} />
            </button>
            {sent && <p className="text-espresso text-sm text-center">Thank you — we'll be in touch shortly.</p>}
          </form>
        </div>
      </div>
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="block text-[11px] uppercase tracking-widest-2 text-espresso-light mb-2">{label}</span>
      {children}
    </label>
  );
}
