import { useState } from 'react';
import { ArrowLeft, Heart, ShoppingBag, Minus, Plus, Check, Truck, RotateCcw, ShieldCheck } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { getProductById, products, formatPKR } from '@/data/products';
import { useCart } from '@/context/CartContext';
import { useWishlist } from '@/context/WishlistContext';
import { ImageWithFallback } from './ImageWithFallback';
import { ProductCard } from './ProductCard';

interface ProductDetailProps {
  productId: string;
  onBack: () => void;
  onOpenProduct: (id: string) => void;
}

export function ProductDetail({ productId, onBack, onOpenProduct }: ProductDetailProps) {
  const product = getProductById(productId);
  const { addProduct } = useCart();
  const { has, toggle } = useWishlist();
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);

  if (!product) {
    return (
      <section className="pt-32 pb-20 min-h-screen bg-ivory flex items-center">
        <div className="text-center max-w-md mx-auto px-6">
          <h2 className="font-serif text-3xl text-espresso mb-4">Product not found</h2>
          <button onClick={onBack} className="btn-primary">Back to Shop</button>
        </div>
      </section>
    );
  }

  const isWishlisted = has(product.id);
  const onSale = product.salePrice !== undefined;
  const price = product.salePrice ?? product.price;

  const handleAdd = () => {
    addProduct(product, qty);
    setAdded(true);
    setTimeout(() => setAdded(false), 1400);
  };

  // Related products — same category, excluding current
  const related = products.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 4);

  return (
    <section className="pt-28 pb-20 min-h-screen bg-ivory">
      <div className="max-w-7xl mx-auto px-5 md:px-8">
        <button onClick={onBack} className="inline-flex items-center gap-2 text-xs uppercase tracking-widest-2 text-espresso hover:text-gold transition-colors mb-8">
          <ArrowLeft size={15} /> Back
        </button>

        <div className="grid md:grid-cols-2 gap-10 lg:gap-16">
          {/* Image */}
          <div>
            <div className="product-image-wrap aspect-[4/5] rounded-sm">
              <ImageWithFallback src={product.image} alt={product.name} className="w-full h-full object-cover" />
            </div>
          </div>

          {/* Info */}
          <div className="flex flex-col">
            <p className="text-[11px] uppercase tracking-widest-2 text-gold mb-3">{product.category}</p>
            <h1 className="font-serif text-3xl md:text-4xl text-espresso mb-4 leading-tight">{product.name}</h1>

            <div className="flex items-center gap-3 mb-6">
              {onSale && <span className="text-base text-espresso-light/50 line-through">{formatPKR(product.price)}</span>}
              <span className="font-serif text-3xl text-espresso">{formatPKR(price)}</span>
              {onSale && <span className="px-2.5 py-1 bg-gold text-espresso text-[10px] uppercase tracking-widest-2">Sale</span>}
            </div>

            <p className="text-espresso-light leading-relaxed mb-8">{product.description}</p>

            {/* Quantity + Add */}
            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center border border-taupe/30">
                <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="w-11 h-11 flex items-center justify-center text-espresso hover:bg-cream transition-colors">
                  <Minus size={15} />
                </button>
                <span className="w-12 text-center text-espresso font-medium">{qty}</span>
                <button onClick={() => setQty((q) => q + 1)} className="w-11 h-11 flex items-center justify-center text-espresso hover:bg-cream transition-colors">
                  <Plus size={15} />
                </button>
              </div>
              <button onClick={handleAdd} className="btn-primary flex-1">
                {added ? <><Check size={15} /> Added to Bag</> : <><ShoppingBag size={15} /> Add to Bag</>}
              </button>
              <button onClick={() => toggle(product)} aria-label="Wishlist" className={`w-11 h-11 border border-taupe/30 flex items-center justify-center transition-colors ${isWishlisted ? 'text-gold border-gold' : 'text-espresso hover:text-gold hover:border-gold'}`}>
                <Heart size={17} strokeWidth={1.5} fill={isWishlisted ? 'currentColor' : 'none'} />
              </button>
            </div>

            {/* Features */}
            <div className="border-t border-taupe/20 pt-6 space-y-3">
              <Feature icon={Truck} title="Free Delivery" desc="On orders over Rs. 3,000 across Sindh" />
              <Feature icon={RotateCcw} title="Easy Returns" desc="7-day return on unworn items" />
              <Feature icon={ShieldCheck} title="Quality Promise" desc="Every piece checked before it ships" />
            </div>

            {/* Meta */}
            <div className="mt-6 pt-6 border-t border-taupe/20 text-xs text-espresso-light/60 space-y-1">
              <p>Category: <span className="text-espresso">{product.category}</span></p>
              <p>Subcategory: <span className="text-espresso">{product.subcategory}</span></p>
              <p>Location: <span className="text-espresso">Khanpur, Sindh, Pakistan</span></p>
            </div>
          </div>
        </div>

        {/* Related */}
        {related.length > 0 && (
          <div className="mt-20">
            <div className="text-center mb-10">
              <p className="section-eyebrow">You May Also Like</p>
              <h2 className="font-serif text-2xl md:text-3xl text-espresso">Complete the Look</h2>
            </div>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-5 md:gap-6">
              {related.map((p) => (
                <ProductCard key={p.id} product={p} onOpen={onOpenProduct} />
              ))}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

function Feature({ icon: Icon, title, desc }: { icon: LucideIcon; title: string; desc: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="w-10 h-10 flex items-center justify-center bg-cream text-gold shrink-0">
        <Icon size={18} strokeWidth={1.5} />
      </div>
      <div>
        <p className="text-sm text-espresso font-medium">{title}</p>
        <p className="text-xs text-espresso-light/60">{desc}</p>
      </div>
    </div>
  );
}
