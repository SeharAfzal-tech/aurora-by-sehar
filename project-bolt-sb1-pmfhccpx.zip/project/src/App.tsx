import { useCallback, useEffect, useState } from 'react';
import { CartProvider, useCart } from '@/context/CartContext';
import { WishlistProvider } from '@/context/WishlistContext';
import { Navbar } from '@/components/Navbar';
import { Hero } from '@/components/Hero';
import { CategorySection } from '@/components/CategorySection';
import { Collections } from '@/components/Collections';
import { Shop } from '@/components/Shop';
import { ProductDetail } from '@/components/ProductDetail';
import { NewArrivals, BestSellers } from '@/components/Featured';
import { About } from '@/components/About';
import { Contact } from '@/components/Contact';
import { Footer } from '@/components/Footer';
import { CartDrawer } from '@/components/CartDrawer';
import { WishlistDrawer } from '@/components/WishlistDrawer';
import { Checkout } from '@/components/Checkout';
import { SearchModal } from '@/components/SearchModal';
import type { CategoryName } from '@/data/products';

type View = 'home' | 'shop' | 'collections' | 'new-arrivals' | 'best-sellers' | 'about' | 'contact' | 'product' | 'checkout' | 'category';

function AppInner() {
  const { closeCart } = useCart();
  const [view, setView] = useState<View>('home');
  const [activeCategory, setActiveCategory] = useState<CategoryName | 'All' | null>(null);
  const [activeCollection, setActiveCollection] = useState<string | null>(null);
  const [activeProductId, setActiveProductId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [wishlistOpen, setWishlistOpen] = useState(false);

  const navigate = useCallback((v: string) => {
    setView(v as View);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const handleNav = useCallback((label: string) => {
    const map: Record<string, View> = {
      home: 'home',
      shop: 'shop',
      collections: 'collections',
      'new-arrivals': 'new-arrivals',
      'best-sellers': 'best-sellers',
      about: 'about',
      contact: 'contact',
    };
    setActiveCategory(null);
    setActiveCollection(null);
    navigate(map[label] ?? 'home');
  }, [navigate]);

  const openProduct = useCallback((id: string) => {
    setActiveProductId(id);
    setView('product');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const openCategory = useCallback((cat: string) => {
    setActiveCategory(cat as CategoryName);
    setActiveCollection(null);
    setView('category');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const openCollection = useCallback((id: string) => {
    setActiveCollection(id);
    setActiveCategory(null);
    setView('collections');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const goToCheckout = useCallback(() => {
    closeCart();
    setView('checkout');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [closeCart]);

  const handleSearchPick = useCallback((id: string) => {
    openProduct(id);
  }, [openProduct]);

  // Reset collection when leaving collections view
  useEffect(() => {
    if (view !== 'collections') setActiveCollection(null);
    if (view !== 'category') setActiveCategory(null);
  }, [view]);

  return (
    <div className="min-h-screen bg-ivory flex flex-col">
      <Navbar onNavigate={handleNav} onOpenSearch={() => setSearchOpen(true)} onOpenWishlist={() => setWishlistOpen(true)} currentView={view} />

      <main className="flex-1">
        {view === 'home' && (
          <>
            <Hero onShopCollection={() => navigate('collections')} onDiscoverNew={() => navigate('new-arrivals')} />
            <CategorySection onShopCategory={openCategory} />
            <NewArrivals onOpenProduct={openProduct} onViewAll={() => navigate('new-arrivals')} />
            <Collections initialCollection={activeCollection} onOpenProduct={openProduct} />
            <BestSellers onOpenProduct={openProduct} onViewAll={() => navigate('best-sellers')} />
            <About />
            <Contact />
          </>
        )}

        {view === 'shop' && (
          <Shop onOpenProduct={openProduct} title="Shop All" subtitle="Every piece in the Velora collection, in one beautiful place." />
        )}

        {view === 'category' && (
          <Shop onOpenProduct={openProduct} initialCategory={activeCategory} title={activeCategory ?? 'Shop'} subtitle="Curated for you." />
        )}

        {view === 'collections' && (
          <Collections initialCollection={activeCollection} onOpenProduct={openProduct} />
        )}

        {view === 'new-arrivals' && (
          <Shop onOpenProduct={openProduct} title="New Arrivals" subtitle="The latest pieces to join the Velora boutique." filterFn={(p) => p.isNew === true} />
        )}

        {view === 'best-sellers' && (
          <Shop onOpenProduct={openProduct} title="Best Sellers" subtitle="The pieces our customers come back for, again and again." filterFn={(p) => p.isBestSeller === true} />
        )}

        {view === 'about' && (
          <>
            <About />
            <Contact />
          </>
        )}

        {view === 'contact' && <Contact />}

        {view === 'product' && activeProductId && (
          <ProductDetail productId={activeProductId} onBack={() => navigate('shop')} onOpenProduct={openProduct} />
        )}

        {view === 'checkout' && (
          <Checkout onBack={() => navigate('shop')} onHome={() => navigate('home')} />
        )}
      </main>

      <Footer onNavigate={handleNav} />

      <CartDrawer onCheckout={goToCheckout} onContinue={() => navigate('shop')} />
      <WishlistDrawer isOpen={wishlistOpen} onClose={() => setWishlistOpen(false)} onOpenProduct={openProduct} />
      <SearchModal open={searchOpen} onClose={() => setSearchOpen(false)} onPickProduct={handleSearchPick} />
    </div>
  );
}

function App() {
  return (
    <CartProvider>
      <WishlistProvider>
        <AppInner />
      </WishlistProvider>
    </CartProvider>
  );
}

export default App;
