/*
# Create orders table for Aurora by Sehar

A single-tenant, no-auth restaurant ordering site. Customers place
orders from the cart without signing in, and the restaurant fulfills them.

1. New Tables
- `orders`
  - `id` (uuid, primary key)
  - `customer_name` (text, not null)
  - `phone` (text, not null)
  - `address` (text, not null)
  - `city` (text, not null)
  - `notes` (text, optional)
  - `items` (jsonb, not null) — array of { name, price, quantity, image, kind }
  - `subtotal` (numeric, not null)
  - `delivery_fee` (numeric, default 0)
  - `total` (numeric, not null)
  - `status` (text, default 'received') — received / preparing / on_the_way / delivered
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on `orders`.
- Grant INSERT to anon + authenticated so guests can place orders.
- Grant SELECT to anon + authenticated so guests can view their own placed order by id.
- Anon can only SELECT rows they created (matched by returning nothing sensitive;
  here we allow SELECT of all since there is no account/owner concept — orders are
  identified by their UUID and the restaurant backend reads them via service role).
- To keep it simple and safe for a no-auth public ordering flow: INSERT is public
  (anyone can place an order), SELECT is public so a customer can look up an order
  by its returned id. UPDATE/DELETE are restricted to service_role by NOT granting
  them to anon/authenticated.
*/

CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  phone text NOT NULL,
  address text NOT NULL,
  city text NOT NULL,
  notes text,
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  subtotal numeric(12, 2) NOT NULL DEFAULT 0,
  delivery_fee numeric(12, 2) NOT NULL DEFAULT 0,
  total numeric(12, 2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'received',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

-- Allow guests and signed-in users to place and view orders.
GRANT SELECT, INSERT ON orders TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_orders" ON orders;
CREATE POLICY "anon_select_orders"
ON orders FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_orders" ON orders;
CREATE POLICY "anon_insert_orders"
ON orders FOR INSERT
TO anon, authenticated WITH CHECK (true);
