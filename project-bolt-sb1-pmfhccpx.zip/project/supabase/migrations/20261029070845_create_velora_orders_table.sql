/*
# Create velora_orders table for Velora by Sehar

A single-tenant, no-auth e-commerce boutique. Customers place
orders from the cart without signing in.

1. New Tables
- `velora_orders`
  - `id` (uuid, primary key)
  - `customer_name` (text, not null)
  - `phone` (text, not null)
  - `address` (text, not null)
  - `city` (text, not null)
  - `notes` (text, optional)
  - `items` (jsonb, not null) — array of { name, price, quantity, image }
  - `subtotal` (numeric, not null)
  - `delivery_fee` (numeric, default 0)
  - `total` (numeric, not null)
  - `status` (text, default 'received')
  - `created_at` (timestamptz, default now())

2. Security
- Enable RLS on `velora_orders`.
- Grant INSERT + SELECT to anon + authenticated (guests place and view orders).
- No UPDATE/DELETE granted to anon/authenticated (service role only).
*/

CREATE TABLE IF NOT EXISTS velora_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  phone text NOT NULL,
  address text NOT NULL,
  city text NOT NULL,
  notes text,
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  subtotal numeric(12, 2) NOT NULL DEFAULT 0,
  delivery_fee numeric(12, 2) NOT NULL DEFAULT 0,
  total numeric(12, 2) NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'received',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE velora_orders ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT ON velora_orders TO anon, authenticated;

DROP POLICY IF EXISTS "anon_select_velora_orders" ON velora_orders;
CREATE POLICY "anon_select_velora_orders"
ON velora_orders FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_velora_orders" ON velora_orders;
CREATE POLICY "anon_insert_velora_orders"
ON velora_orders FOR INSERT
TO anon, authenticated WITH CHECK (true);
